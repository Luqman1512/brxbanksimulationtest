import { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';

function Home() {
  const navigate = useNavigate();

  useEffect(() => {
    // Redirect to the main app route
    navigate('/', { replace: true });
  }, [navigate]);

  return (
    <div className="w-screen h-screen flex items-center justify-center bg-gradient-brx">
      <div className="text-center text-white">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-white mx-auto mb-4"></div>
        <p>Loading BRX SuperBank...</p>
      </div>
    </div>
  );
}

export default Home;
import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { 
  CreditCard, 
  Snowflake, 
  Settings, 
  Eye, 
  EyeOff, 
  Wifi, 
  WifiOff, 
  DollarSign,
  Plus,
  MoreVertical
} from 'lucide-react';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from '@/components/ui/dropdown-menu';

interface CardData {
  id: string;
  name: string;
  number: string;
  type: 'debit' | 'credit';
  status: 'active' | 'frozen' | 'blocked';
  balance: number;
  limit?: number;
  contactless: boolean;
  spendLimit: number;
  frontImage?: string;
  backImage?: string;
}

interface CardManagementProps {
  expanded?: boolean;
}

const CardManagement: React.FC<CardManagementProps> = ({ expanded = false }) => {
  const [cards, setCards] = useState<CardData[]>([
    {
      id: '1',
      name: 'Primary Debit Card',
      number: '**** **** **** 1234',
      type: 'debit',
      status: 'active',
      balance: 12450.75,
      contactless: true,
      spendLimit: 5000,
      frontImage: 'https://images.unsplash.com/photo-1556742049-0cfed4f6a45d?w=400&q=80'
    },
    {
      id: '2',
      name: 'Rewards Credit Card',
      number: '**** **** **** 5678',
      type: 'credit',
      status: 'active',
      balance: 2340.50,
      limit: 15000,
      contactless: true,
      spendLimit: 3000,
      frontImage: 'https://images.unsplash.com/photo-1563013544-824ae1b704d3?w=400&q=80'
    }
  ]);

  const [showCardNumbers, setShowCardNumbers] = useState(false);
  const [selectedCard, setSelectedCard] = useState<CardData | null>(null);

  const toggleCardStatus = (cardId: string) => {
    setCards(cards.map(card => 
      card.id === cardId 
        ? { ...card, status: card.status === 'active' ? 'frozen' : 'active' }
        : card
    ));
  };

  const toggleContactless = (cardId: string) => {
    setCards(cards.map(card => 
      card.id === cardId 
        ? { ...card, contactless: !card.contactless }
        : card
    ));
  };

  const updateSpendLimit = (cardId: string, newLimit: number) => {
    setCards(cards.map(card => 
      card.id === cardId 
        ? { ...card, spendLimit: newLimit }
        : card
    ));
  };

  const CardComponent: React.FC<{ card: CardData }> = ({ card }) => (
    <Card className="relative overflow-hidden">
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="relative">
              {card.frontImage ? (
                <img 
                  src={card.frontImage} 
                  alt={`${card.name} front`}
                  className="w-16 h-10 object-cover rounded-lg shadow-md"
                />
              ) : (
                <div className="w-16 h-10 bg-gradient-brx rounded-lg flex items-center justify-center">
                  <CreditCard className="h-6 w-6 text-white" />
                </div>
              )}
              <Badge 
                variant={card.status === 'active' ? 'default' : 'destructive'}
                className="absolute -top-2 -right-2 text-xs"
              >
                {card.status}
              </Badge>
            </div>
            <div>
              <h3 className="font-semibold">{card.name}</h3>
              <p className="text-sm text-muted-foreground font-mono">
                {showCardNumbers ? card.number : '**** **** **** ****'}
              </p>
            </div>
          </div>
          
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
                <MoreVertical className="h-4 w-4" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem onClick={() => setSelectedCard(card)}>
                <Settings className="mr-2 h-4 w-4" />
                Card Settings
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => toggleCardStatus(card.id)}>
                <Snowflake className="mr-2 h-4 w-4" />
                {card.status === 'active' ? 'Freeze Card' : 'Unfreeze Card'}
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </CardHeader>
      
      <CardContent className="space-y-4">
        <div className="flex justify-between items-center">
          <span className="text-sm text-muted-foreground">
            {card.type === 'debit' ? 'Available Balance' : 'Available Credit'}
          </span>
          <span className="font-semibold">
            ${card.type === 'debit' ? card.balance.toLocaleString() : (card.limit! - card.balance).toLocaleString()}
          </span>
        </div>
        
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            {card.contactless ? <Wifi className="h-4 w-4 text-green-600" /> : <WifiOff className="h-4 w-4 text-gray-400" />}
            <span className="text-sm">Contactless</span>
          </div>
          <Switch 
            checked={card.contactless} 
            onCheckedChange={() => toggleContactless(card.id)}
            disabled={card.status !== 'active'}
          />
        </div>
        
        <div className="flex items-center justify-between">
          <span className="text-sm">Daily Spend Limit</span>
          <span className="text-sm font-medium">${card.spendLimit.toLocaleString()}</span>
        </div>
      </CardContent>
    </Card>
  );

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h2 className="text-xl font-semibold font-poppins">
          {expanded ? 'Card Management' : 'Your Cards'}
        </h2>
        <div className="flex items-center gap-2">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setShowCardNumbers(!showCardNumbers)}
          >
            {showCardNumbers ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
          </Button>
          {expanded && (
            <Button size="sm" className="bg-gradient-brx">
              <Plus className="h-4 w-4 mr-2" />
              Add Card
            </Button>
          )}
        </div>
      </div>

      <div className={`grid gap-4 ${expanded ? 'grid-cols-1 md:grid-cols-2' : 'grid-cols-1'}`}>
        {cards.map(card => (
          <CardComponent key={card.id} card={card} />
        ))}
      </div>

      {/* Card Settings Dialog */}
      <Dialog open={!!selectedCard} onOpenChange={() => setSelectedCard(null)}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Card Settings</DialogTitle>
            <DialogDescription>
              Manage settings for {selectedCard?.name}
            </DialogDescription>
          </DialogHeader>
          
          {selectedCard && (
            <div className="space-y-6">
              <div className="flex items-center justify-center">
                {selectedCard.frontImage ? (
                  <img 
                    src={selectedCard.frontImage} 
                    alt={`${selectedCard.name} front`}
                    className="w-64 h-40 object-cover rounded-xl shadow-lg"
                  />
                ) : (
                  <div className="w-64 h-40 bg-gradient-brx rounded-xl flex items-center justify-center">
                    <CreditCard className="h-16 w-16 text-white" />
                  </div>
                )}
              </div>
              
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <Label htmlFor="freeze-card">Card Status</Label>
                  <Button
                    variant={selectedCard.status === 'active' ? 'destructive' : 'default'}
                    size="sm"
                    onClick={() => toggleCardStatus(selectedCard.id)}
                  >
                    {selectedCard.status === 'active' ? 'Freeze Card' : 'Unfreeze Card'}
                  </Button>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="spend-limit">Daily Spend Limit</Label>
                  <div className="flex items-center gap-2">
                    <DollarSign className="h-4 w-4 text-muted-foreground" />
                    <Input
                      id="spend-limit"
                      type="number"
                      value={selectedCard.spendLimit}
                      onChange={(e) => updateSpendLimit(selectedCard.id, parseInt(e.target.value) || 0)}
                      className="flex-1"
                    />
                  </div>
                </div>
                
                <div className="flex items-center justify-between">
                  <Label htmlFor="contactless">Contactless Payments</Label>
                  <Switch 
                    id="contactless"
                    checked={selectedCard.contactless} 
                    onCheckedChange={() => toggleContactless(selectedCard.id)}
                    disabled={selectedCard.status !== 'active'}
                  />
                </div>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default CardManagement;
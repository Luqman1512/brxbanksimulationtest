import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { 
  ArrowUpRight, 
  ArrowDownLeft, 
  Search, 
  Filter,
  ShoppingCart,
  Coffee,
  Car,
  Home,
  Smartphone,
  MoreHorizontal
} from 'lucide-react';

interface Transaction {
  id: string;
  type: 'credit' | 'debit';
  amount: number;
  description: string;
  category: string;
  date: string;
  status: 'completed' | 'pending' | 'failed';
  merchant?: string;
  icon?: React.ReactNode;
}

interface TransactionHistoryProps {
  limit?: number;
}

const TransactionHistory: React.FC<TransactionHistoryProps> = ({ limit }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [filterCategory, setFilterCategory] = useState('all');
  
  const mockTransactions: Transaction[] = [
    {
      id: '1',
      type: 'debit',
      amount: 85.50,
      description: 'Grocery Shopping',
      category: 'Food & Dining',
      date: '2024-01-15',
      status: 'completed',
      merchant: 'Whole Foods Market',
      icon: <ShoppingCart className="h-4 w-4" />
    },
    {
      id: '2',
      type: 'credit',
      amount: 2500.00,
      description: 'Salary Deposit',
      category: 'Income',
      date: '2024-01-15',
      status: 'completed',
      merchant: 'BRX Corporation',
      icon: <ArrowDownLeft className="h-4 w-4" />
    },
    {
      id: '3',
      type: 'debit',
      amount: 12.75,
      description: 'Coffee Shop',
      category: 'Food & Dining',
      date: '2024-01-14',
      status: 'completed',
      merchant: 'Starbucks',
      icon: <Coffee className="h-4 w-4" />
    },
    {
      id: '4',
      type: 'debit',
      amount: 45.00,
      description: 'Gas Station',
      category: 'Transportation',
      date: '2024-01-14',
      status: 'completed',
      merchant: 'Shell',
      icon: <Car className="h-4 w-4" />
    },
    {
      id: '5',
      type: 'debit',
      amount: 1200.00,
      description: 'Rent Payment',
      category: 'Housing',
      date: '2024-01-01',
      status: 'completed',
      merchant: 'Property Management Co.',
      icon: <Home className="h-4 w-4" />
    },
    {
      id: '6',
      type: 'debit',
      amount: 89.99,
      description: 'Phone Bill',
      category: 'Utilities',
      date: '2024-01-01',
      status: 'completed',
      merchant: 'Verizon',
      icon: <Smartphone className="h-4 w-4" />
    },
    {
      id: '7',
      type: 'debit',
      amount: 25.00,
      description: 'ATM Withdrawal',
      category: 'Cash',
      date: '2024-01-13',
      status: 'pending',
      merchant: 'BRX ATM #1234'
    }
  ];

  const filteredTransactions = mockTransactions
    .filter(transaction => 
      filterCategory === 'all' || transaction.category.toLowerCase().includes(filterCategory.toLowerCase())
    )
    .filter(transaction =>
      transaction.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
      transaction.merchant?.toLowerCase().includes(searchTerm.toLowerCase())
    )
    .slice(0, limit);

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD'
    }).format(amount);
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric'
    });
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed': return 'bg-green-100 text-green-800';
      case 'pending': return 'bg-yellow-100 text-yellow-800';
      case 'failed': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2">
            Transaction History
            {!limit && (
              <Badge variant="outline" className="ml-2">
                {filteredTransactions.length} transactions
              </Badge>
            )}
          </CardTitle>
          {!limit && (
            <div className="flex items-center gap-2">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Search transactions..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10 w-64"
                />
              </div>
              <Select value={filterCategory} onValueChange={setFilterCategory}>
                <SelectTrigger className="w-40">
                  <Filter className="h-4 w-4 mr-2" />
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Categories</SelectItem>
                  <SelectItem value="food">Food & Dining</SelectItem>
                  <SelectItem value="transportation">Transportation</SelectItem>
                  <SelectItem value="housing">Housing</SelectItem>
                  <SelectItem value="utilities">Utilities</SelectItem>
                  <SelectItem value="income">Income</SelectItem>
                </SelectContent>
              </Select>
            </div>
          )}
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {filteredTransactions.map((transaction) => (
            <div key={transaction.id} className="flex items-center justify-between p-4 rounded-lg border hover:bg-gray-50 transition-colors">
              <div className="flex items-center gap-4">
                <div className={`p-2 rounded-full ${
                  transaction.type === 'credit' ? 'bg-green-100' : 'bg-blue-100'
                }`}>
                  {transaction.icon || (
                    transaction.type === 'credit' 
                      ? <ArrowDownLeft className="h-4 w-4 text-green-600" />
                      : <ArrowUpRight className="h-4 w-4 text-blue-600" />
                  )}
                </div>
                <div>
                  <p className="font-medium">{transaction.description}</p>
                  <div className="flex items-center gap-2 text-sm text-muted-foreground">
                    <span>{transaction.merchant}</span>
                    <span>•</span>
                    <span>{formatDate(transaction.date)}</span>
                    <Badge variant="outline" className={`text-xs ${getStatusColor(transaction.status)}`}>
                      {transaction.status}
                    </Badge>
                  </div>
                </div>
              </div>
              <div className="text-right">
                <p className={`font-semibold ${
                  transaction.type === 'credit' ? 'text-green-600' : 'text-gray-900'
                }`}>
                  {transaction.type === 'credit' ? '+' : '-'}{formatCurrency(transaction.amount)}
                </p>
                <p className="text-sm text-muted-foreground">{transaction.category}</p>
              </div>
            </div>
          ))}
          
          {limit && filteredTransactions.length >= limit && (
            <div className="text-center pt-4">
              <Button variant="outline" size="sm">
                View All Transactions
                <MoreHorizontal className="h-4 w-4 ml-2" />
              </Button>
            </div>
          )}
          
          {filteredTransactions.length === 0 && (
            <div className="text-center py-8 text-muted-foreground">
              <p>No transactions found matching your criteria.</p>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
};

export default TransactionHistory;
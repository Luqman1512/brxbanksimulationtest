import React, { useState } from 'react';
import { useAuth } from '../auth/AuthContext';
import Header from './Header';
import AccountSummary from './AccountSummary';
import CardManagement from './CardManagement';
import TransactionHistory from './TransactionHistory';
import QuickActions from './QuickActions';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';

const Dashboard: React.FC = () => {
  const { user } = useAuth();
  const [activeTab, setActiveTab] = useState('overview');

  if (!user) return null;

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      <main className="container mx-auto px-4 py-6 max-w-7xl">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 font-poppins">
            Welcome back, {user.name.split(' ')[0]}
          </h1>
          <p className="text-gray-600 mt-1">Here's what's happening with your account today.</p>
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="grid w-full grid-cols-4 lg:w-auto lg:grid-cols-4">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="cards">Cards</TabsTrigger>
            <TabsTrigger value="transactions">Transactions</TabsTrigger>
            <TabsTrigger value="services">Services</TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              <div className="lg:col-span-2 space-y-6">
                <AccountSummary />
                <QuickActions />
              </div>
              <div className="space-y-6">
                <CardManagement />
                <TransactionHistory limit={5} />
              </div>
            </div>
          </TabsContent>

          <TabsContent value="cards" className="space-y-6">
            <CardManagement expanded />
          </TabsContent>

          <TabsContent value="transactions" className="space-y-6">
            <TransactionHistory />
          </TabsContent>

          <TabsContent value="services" className="space-y-6">
            <QuickActions expanded />
          </TabsContent>
        </Tabs>
      </main>
    </div>
  );
};

export default Dashboard;
import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useToast } from '@/components/ui/use-toast';
import { 
  Send, 
  Receipt, 
  Banknote, 
  TrendingUp, 
  Wallet,
  ArrowUpRight,
  ArrowDownLeft,
  DollarSign,
  User,
  Building
} from 'lucide-react';

interface QuickActionsProps {
  expanded?: boolean;
}

const QuickActions: React.FC<QuickActionsProps> = ({ expanded = false }) => {
  const [transferAmount, setTransferAmount] = useState('');
  const [transferRecipient, setTransferRecipient] = useState('');
  const [billAmount, setBillAmount] = useState('');
  const [billPayee, setBillPayee] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();

  const handleTransfer = async () => {
    setIsLoading(true);
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    toast({
      title: "Transfer Successful",
      description: `$${transferAmount} sent to ${transferRecipient}`,
    });
    
    setTransferAmount('');
    setTransferRecipient('');
    setIsLoading(false);
  };

  const handleBillPayment = async () => {
    setIsLoading(true);
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    toast({
      title: "Bill Payment Successful",
      description: `$${billAmount} paid to ${billPayee}`,
    });
    
    setBillAmount('');
    setBillPayee('');
    setIsLoading(false);
  };

  const quickActionItems = [
    {
      title: 'Send Money',
      description: 'Transfer to friends & family',
      icon: <Send className="h-6 w-6" />,
      color: 'bg-blue-500',
      action: 'transfer'
    },
    {
      title: 'Pay Bills',
      description: 'Utilities, rent, and more',
      icon: <Receipt className="h-6 w-6" />,
      color: 'bg-green-500',
      action: 'bills'
    },
    {
      title: 'Loans',
      description: 'Apply for personal loans',
      icon: <Banknote className="h-6 w-6" />,
      color: 'bg-purple-500',
      action: 'loans'
    },
    {
      title: 'Investments',
      description: 'Grow your wealth',
      icon: <TrendingUp className="h-6 w-6" />,
      color: 'bg-orange-500',
      action: 'investments'
    },
    {
      title: 'Digital Wallet',
      description: 'Mobile payments',
      icon: <Wallet className="h-6 w-6" />,
      color: 'bg-indigo-500',
      action: 'wallet'
    }
  ];

  const displayItems = expanded ? quickActionItems : quickActionItems.slice(0, 4);

  return (
    <div className="space-y-4">
      <h2 className="text-xl font-semibold font-poppins">
        {expanded ? 'Banking Services' : 'Quick Actions'}
      </h2>
      
      <div className={`grid gap-4 ${expanded ? 'grid-cols-1 md:grid-cols-2 lg:grid-cols-3' : 'grid-cols-2 md:grid-cols-4'}`}>
        {displayItems.map((item) => (
          <Dialog key={item.action}>
            <DialogTrigger asChild>
              <Card className="cursor-pointer hover:shadow-md transition-shadow">
                <CardContent className="p-6">
                  <div className="flex flex-col items-center text-center space-y-3">
                    <div className={`p-3 rounded-full ${item.color} text-white`}>
                      {item.icon}
                    </div>
                    <div>
                      <h3 className="font-semibold">{item.title}</h3>
                      <p className="text-sm text-muted-foreground">{item.description}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </DialogTrigger>
            
            <DialogContent className="sm:max-w-md">
              <DialogHeader>
                <DialogTitle className="flex items-center gap-2">
                  <div className={`p-2 rounded-full ${item.color} text-white`}>
                    {item.icon}
                  </div>
                  {item.title}
                </DialogTitle>
                <DialogDescription>
                  {item.description}
                </DialogDescription>
              </DialogHeader>
              
              {item.action === 'transfer' && (
                <div className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="recipient">Recipient</Label>
                    <div className="relative">
                      <User className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                      <Input
                        id="recipient"
                        placeholder="Enter recipient name or email"
                        value={transferRecipient}
                        onChange={(e) => setTransferRecipient(e.target.value)}
                        className="pl-10"
                      />
                    </div>
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="amount">Amount</Label>
                    <div className="relative">
                      <DollarSign className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                      <Input
                        id="amount"
                        type="number"
                        placeholder="0.00"
                        value={transferAmount}
                        onChange={(e) => setTransferAmount(e.target.value)}
                        className="pl-10"
                      />
                    </div>
                  </div>
                  
                  <Button 
                    onClick={handleTransfer} 
                    className="w-full bg-gradient-brx"
                    disabled={!transferAmount || !transferRecipient || isLoading}
                  >
                    {isLoading ? 'Processing...' : 'Send Money'}
                    <ArrowUpRight className="h-4 w-4 ml-2" />
                  </Button>
                </div>
              )}
              
              {item.action === 'bills' && (
                <div className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="payee">Payee</Label>
                    <Select value={billPayee} onValueChange={setBillPayee}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select a payee" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="electric">Electric Company</SelectItem>
                        <SelectItem value="gas">Gas Company</SelectItem>
                        <SelectItem value="water">Water Department</SelectItem>
                        <SelectItem value="internet">Internet Provider</SelectItem>
                        <SelectItem value="phone">Phone Company</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="bill-amount">Amount</Label>
                    <div className="relative">
                      <DollarSign className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                      <Input
                        id="bill-amount"
                        type="number"
                        placeholder="0.00"
                        value={billAmount}
                        onChange={(e) => setBillAmount(e.target.value)}
                        className="pl-10"
                      />
                    </div>
                  </div>
                  
                  <Button 
                    onClick={handleBillPayment} 
                    className="w-full bg-gradient-brx"
                    disabled={!billAmount || !billPayee || isLoading}
                  >
                    {isLoading ? 'Processing...' : 'Pay Bill'}
                    <Receipt className="h-4 w-4 ml-2" />
                  </Button>
                </div>
              )}
              
              {(item.action === 'loans' || item.action === 'investments' || item.action === 'wallet') && (
                <div className="text-center py-8">
                  <div className={`p-4 rounded-full ${item.color} text-white mx-auto w-fit mb-4`}>
                    {item.icon}
                  </div>
                  <h3 className="font-semibold mb-2">Coming Soon</h3>
                  <p className="text-sm text-muted-foreground mb-4">
                    This feature is currently under development and will be available soon.
                  </p>
                  <Button variant="outline" className="w-full">
                    Get Notified
                  </Button>
                </div>
              )}
            </DialogContent>
          </Dialog>
        ))}
      </div>
      
      {!expanded && (
        <Card className="bg-gradient-to-r from-blue-50 to-indigo-50 border-blue-200">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="font-semibold text-blue-900">Need Help?</h3>
                <p className="text-sm text-blue-700">Our support team is available 24/7</p>
              </div>
              <Button variant="outline" className="border-blue-300 text-blue-700 hover:bg-blue-100">
                Contact Support
              </Button>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
};

export default QuickActions;
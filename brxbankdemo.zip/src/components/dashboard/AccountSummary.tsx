import React from 'react';
import { useAuth } from '../auth/AuthContext';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { TrendingUp, TrendingDown, Eye, EyeOff, DollarSign, PiggyBank, CreditCard } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useState } from 'react';

const AccountSummary: React.FC = () => {
  const { user } = useAuth();
  const [showBalance, setShowBalance] = useState(true);

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD'
    }).format(amount);
  };

  const mockData = {
    monthlyIncome: 5420.00,
    monthlyExpenses: 3240.50,
    savingsGoal: 15000,
    currentSavings: 8750,
    creditScore: 742
  };

  return (
    <div className="space-y-6">
      {/* Main Balance Card */}
      <Card className="bg-gradient-brx text-white border-0 shadow-lg">
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="text-white/90 text-sm font-medium">Total Balance</CardTitle>
              <div className="flex items-center gap-3 mt-2">
                <span className="text-3xl font-bold font-poppins">
                  {showBalance ? formatCurrency(user?.balance || 0) : '••••••'}
                </span>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setShowBalance(!showBalance)}
                  className="text-white/80 hover:text-white hover:bg-white/10 h-8 w-8 p-0"
                >
                  {showBalance ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                </Button>
              </div>
            </div>
            <div className="text-right">
              <p className="text-white/90 text-sm">Account</p>
              <p className="text-white font-mono text-lg">{user?.accountNumber}</p>
            </div>
          </div>
        </CardHeader>
        <CardContent className="pt-0">
          <div className="flex items-center gap-2">
            <TrendingUp className="h-4 w-4 text-green-300" />
            <span className="text-green-300 text-sm">+2.5% from last month</span>
          </div>
        </CardContent>
      </Card>

      {/* Financial Overview Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Monthly Income</CardTitle>
            <TrendingUp className="h-4 w-4 text-green-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">
              {formatCurrency(mockData.monthlyIncome)}
            </div>
            <p className="text-xs text-muted-foreground">
              +12% from last month
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Monthly Expenses</CardTitle>
            <TrendingDown className="h-4 w-4 text-red-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-red-600">
              {formatCurrency(mockData.monthlyExpenses)}
            </div>
            <p className="text-xs text-muted-foreground">
              -5% from last month
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Credit Score</CardTitle>
            <Badge variant="secondary" className="bg-green-100 text-green-800">
              Excellent
            </Badge>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">
              {mockData.creditScore}
            </div>
            <p className="text-xs text-muted-foreground">
              +15 points this month
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Savings Goal */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center gap-2">
              <PiggyBank className="h-5 w-5 text-blue-600" />
              Savings Goal Progress
            </CardTitle>
            <Badge variant="outline">
              {Math.round((mockData.currentSavings / mockData.savingsGoal) * 100)}% Complete
            </Badge>
          </div>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            <div className="flex justify-between text-sm">
              <span>Current: {formatCurrency(mockData.currentSavings)}</span>
              <span>Goal: {formatCurrency(mockData.savingsGoal)}</span>
            </div>
            <div className="w-full bg-gray-200 rounded-full h-3">
              <div 
                className="bg-gradient-brx h-3 rounded-full transition-all duration-300"
                style={{ width: `${(mockData.currentSavings / mockData.savingsGoal) * 100}%` }}
              ></div>
            </div>
            <p className="text-xs text-muted-foreground">
              {formatCurrency(mockData.savingsGoal - mockData.currentSavings)} remaining to reach your goal
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default AccountSummary;
import React from 'react';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { AlertTriangle } from 'lucide-react';

const DemoModeBanner: React.FC = () => {
  return (
    <Alert className="rounded-none border-x-0 border-t-0 bg-amber-50 border-amber-200">
      <AlertTriangle className="h-4 w-4 text-amber-600" />
      <AlertDescription className="text-amber-800 font-medium">
        <strong>DEMO MODE:</strong> This is a demonstration application. No real financial transactions or data are processed.
      </AlertDescription>
    </Alert>
  );
};

export default DemoModeBanner;